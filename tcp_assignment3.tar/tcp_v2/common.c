#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "common.h"

int fill_sockaddr(struct sockaddr_in *addr, const char *ip, const char *port)
{
    char *end;
    long p;

    errno = 0;
    p = strtol(port, &end, 10);
    if (errno != 0 || *port == '\0' || *end != '\0' ||
        p < MIN_PORT || p > MAX_PORT) {
        fprintf(stderr, "Error: invalid port \"%s\" (must be a number between %d and %d)\n",
                port, MIN_PORT, MAX_PORT);
        return -1;
    }

    memset(addr, 0, sizeof(*addr));
    addr->sin_family = AF_INET;
    addr->sin_port = htons((unsigned short)p);

    if (inet_pton(AF_INET, ip, &addr->sin_addr) != 1) {
        fprintf(stderr, "Error: \"%s\" is not a valid IPv4 address\n", ip);
        return -1;
    }
    return 0;
}

void msg_to_network(struct mesg *m)
{
    m->seq_no = htonl(m->seq_no);
    m->reserved = htons(m->reserved);
}

void msg_to_host(struct mesg *m)
{
    m->seq_no = ntohl(m->seq_no);
    m->reserved = ntohs(m->reserved);
}

int send_msg(int fd, const struct mesg *m)
{
    struct mesg wire = *m;
    ssize_t n;

    msg_to_network(&wire);
    n = write(fd, &wire, sizeof(wire));
    if (n < 0)
        return -1;
    if ((size_t)n != sizeof(wire)) {
        errno = EIO;
        return -1;
    }
    return 0;
}

int recv_msg(int fd, struct mesg *m)
{
    ssize_t n;

    do {
        n = read(fd, m, sizeof(*m));
    } while (n < 0 && errno == EINTR);

    if (n == 0)
        return 0;                   /* EOF: peer closed, not an error */
    if (n < 0)
        return -1;
    if ((size_t)n != sizeof(*m)) {
        errno = EPROTO;             /* truncated message */
        return -1;
    }

    msg_to_host(m);
    return 1;
}
