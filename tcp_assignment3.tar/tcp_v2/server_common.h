#ifndef SERVER_COMMON_H
#define SERVER_COMMON_H

/* Functions shared by the two server programs (fork and select). */

#include <stddef.h>
#include <netinet/in.h>

#define BACKLOG 10

/* socket + SO_REUSEADDR + bind + listen. Returns the listening fd, or -1
 * (after printing a message) on failure. */
int create_listen_socket(const char *ip, const char *port);

/* Writes "a.b.c.d:port" for the peer into buf. */
void format_peer(const struct sockaddr_in *addr, char *buf, size_t len);

/* Reads ONE request from connfd, prints it, increments seq_no and sends the
 * reply. Returns 1 if a request was served, 0 if the client closed the
 * connection, -1 on error (message already printed). */
int serve_request(int connfd, const char *who);

#endif
