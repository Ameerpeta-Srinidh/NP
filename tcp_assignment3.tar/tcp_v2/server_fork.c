/* Concurrent server: one child PROCESS per client. */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include "common.h"
#include "server_common.h"

static void sigchld_handler(int signo)
{
    int saved_errno = errno;

    (void)signo;
    while (waitpid(-1, NULL, WNOHANG) > 0)      /* reap every finished child */
        ;
    errno = saved_errno;
}

static void install_sigchld_handler(void)
{
    struct sigaction sa;

    sa.sa_handler = sigchld_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;    /* restart accept() after the handler */
    if (sigaction(SIGCHLD, &sa, NULL) < 0) {
        perror("sigaction(SIGCHLD)");
        exit(EXIT_FAILURE);
    }
}

/* runs in the child */
static void serve_client(int connfd, const char *who)
{
    int rc;

    while ((rc = serve_request(connfd, who)) > 0)
        ;
    if (rc == 0)
        printf("[%s] client disconnected\n", who);
    close(connfd);
}

int main(int argc, char *argv[])
{
    int listenfd, connfd;
    pid_t pid;

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <ipaddress> <portno>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    setvbuf(stdout, NULL, _IOLBF, 0);   /* no unflushed output to duplicate on fork() */

    listenfd = create_listen_socket(argv[1], argv[2]);
    if (listenfd < 0)
        exit(EXIT_FAILURE);

    signal(SIGPIPE, SIG_IGN);
    install_sigchld_handler();

    printf("Concurrent (fork) server listening on %s:%s\n", argv[1], argv[2]);

    for (;;) {
        struct sockaddr_in client_addr;
        socklen_t len = sizeof(client_addr);        /* must be reset on every accept() */
        char who[INET_ADDRSTRLEN + 8];

        connfd = accept(listenfd, (struct sockaddr *)&client_addr, &len);
        if (connfd < 0) {
            if (errno != EINTR)
                fprintf(stderr, "accept failed: %s\n", strerror(errno));
            continue;                               /* keep serving other clients */
        }
        format_peer(&client_addr, who, sizeof(who));

        pid = fork();
        if (pid < 0) {
            perror("fork");
            close(connfd);
            continue;
        }
        if (pid == 0) {                             /* child */
            close(listenfd);
            printf("[%s] connected, served by child pid %d\n", who, (int)getpid());
            serve_client(connfd, who);
            exit(EXIT_SUCCESS);
        }
        close(connfd);                              /* parent: child owns this connection */
    }
}
