/* Iterative server: ONE process, select() multiplexes up to MAX_CLIENTS clients. */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "common.h"
#include "server_common.h"

#define MAX_CLIENTS 5

struct client_table {
    int fd[MAX_CLIENTS];                        /* -1 means the slot is free */
    char who[MAX_CLIENTS][INET_ADDRSTRLEN + 8];
    int count;                                  /* slots in use */
};

static void table_init(struct client_table *t)
{
    int i;

    for (i = 0; i < MAX_CLIENTS; i++)
        t->fd[i] = -1;
    t->count = 0;
}

static void table_add(struct client_table *t, int connfd, const char *who)
{
    int i;

    for (i = 0; i < MAX_CLIENTS; i++) {
        if (t->fd[i] < 0) {
            t->fd[i] = connfd;
            strncpy(t->who[i], who, sizeof(t->who[i]) - 1);
            t->who[i][sizeof(t->who[i]) - 1] = '\0';
            t->count++;
            return;
        }
    }
}

static void table_remove(struct client_table *t, int i)
{
    close(t->fd[i]);
    t->fd[i] = -1;
    t->count--;
}

/* builds the fd_set to watch; returns the highest fd */
static int build_fdset(const struct client_table *t, int listenfd, fd_set *set)
{
    int i, maxfd = -1;

    FD_ZERO(set);
    if (t->count < MAX_CLIENTS) {   /* full: stop accepting, extra clients wait in the backlog */
        FD_SET(listenfd, set);
        maxfd = listenfd;
    }
    for (i = 0; i < MAX_CLIENTS; i++) {
        if (t->fd[i] >= 0) {
            FD_SET(t->fd[i], set);
            if (t->fd[i] > maxfd)
                maxfd = t->fd[i];
        }
    }
    return maxfd;
}

static void accept_client(int listenfd, struct client_table *t)
{
    struct sockaddr_in client_addr;
    socklen_t len = sizeof(client_addr);
    char who[INET_ADDRSTRLEN + 8];
    int connfd;

    connfd = accept(listenfd, (struct sockaddr *)&client_addr, &len);
    if (connfd < 0) {
        if (errno != EINTR)
            fprintf(stderr, "accept failed: %s\n", strerror(errno));
        return;                                     /* keep running */
    }
    format_peer(&client_addr, who, sizeof(who));
    table_add(t, connfd, who);
    printf("[%s] connected (%d/%d clients)\n", who, t->count, MAX_CLIENTS);
}

static void serve_ready_clients(struct client_table *t, const fd_set *ready)
{
    int i, rc;

    for (i = 0; i < MAX_CLIENTS; i++) {
        if (t->fd[i] < 0 || !FD_ISSET(t->fd[i], ready))
            continue;
        rc = serve_request(t->fd[i], t->who[i]);
        if (rc <= 0) {
            if (rc == 0)
                printf("[%s] client disconnected\n", t->who[i]);
            table_remove(t, i);
            printf("(%d/%d clients)\n", t->count, MAX_CLIENTS);
        }
    }
}

int main(int argc, char *argv[])
{
    struct client_table table;
    int listenfd;

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <ipaddress> <portno>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    setvbuf(stdout, NULL, _IOLBF, 0);

    listenfd = create_listen_socket(argv[1], argv[2]);
    if (listenfd < 0)
        exit(EXIT_FAILURE);

    /* one dead client must not kill the only server process */
    signal(SIGPIPE, SIG_IGN);

    table_init(&table);
    printf("Iterative (select) server listening on %s:%s, max %d clients\n",
           argv[1], argv[2], MAX_CLIENTS);

    for (;;) {
        fd_set rset;
        int maxfd = build_fdset(&table, listenfd, &rset);

        if (select(maxfd + 1, &rset, NULL, NULL, NULL) < 0) {
            if (errno == EINTR)
                continue;
            perror("select");
            exit(EXIT_FAILURE);
        }
        if (table.count < MAX_CLIENTS && FD_ISSET(listenfd, &rset))
            accept_client(listenfd, &table);
        serve_ready_clients(&table, &rset);
    }
}
