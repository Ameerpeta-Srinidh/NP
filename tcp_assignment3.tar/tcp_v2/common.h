#ifndef COMMON_H
#define COMMON_H

/* Functions needed by BOTH the client and the servers. */

#include <netinet/in.h>
#include "mesg.h"

#define MIN_PORT 1024       /* ports below this are reserved for system servers */
#define MAX_PORT 65535

/* Validates ip/port strings and fills *addr. Prints a message and returns -1
 * if either is invalid, 0 on success. */
int fill_sockaddr(struct sockaddr_in *addr, const char *ip, const char *port);

/* Byte-order conversion of the numeric fields of a message. */
void msg_to_network(struct mesg *m);
void msg_to_host(struct mesg *m);

/* Send *m (given in host order) on fd. Returns 0 on success, -1 on error
 * (errno is set). */
int send_msg(int fd, const struct mesg *m);

/* Receive one message from fd into *m and convert it to host order.
 * Returns 1 on success, 0 if the peer closed the connection (EOF),
 * -1 on error (errno is set). */
int recv_msg(int fd, struct mesg *m);

#endif
