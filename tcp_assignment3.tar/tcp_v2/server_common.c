#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "common.h"
#include "server_common.h"

int create_listen_socket(const char *ip, const char *port)
{
    struct sockaddr_in addr;
    int fd, on = 1;

    if (fill_sockaddr(&addr, ip, port) < 0)
        return -1;

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket");
        return -1;
    }
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
        perror("setsockopt(SO_REUSEADDR)");
        close(fd);
        return -1;
    }
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        fprintf(stderr, "Error: cannot bind to %s:%s: %s\n", ip, port, strerror(errno));
        close(fd);
        return -1;
    }
    if (listen(fd, BACKLOG) < 0) {
        perror("listen");
        close(fd);
        return -1;
    }
    return fd;
}

void format_peer(const struct sockaddr_in *addr, char *buf, size_t len)
{
    char ip[INET_ADDRSTRLEN];

    if (inet_ntop(AF_INET, &addr->sin_addr, ip, sizeof(ip)) == NULL)
        strcpy(ip, "?");
    snprintf(buf, len, "%s:%u", ip, (unsigned)ntohs(addr->sin_port));
}

int serve_request(int connfd, const char *who)
{
    struct mesg m;
    int rc;

    rc = recv_msg(connfd, &m);
    if (rc == 0)
        return 0;
    if (rc < 0) {
        fprintf(stderr, "[%s] error reading from client: %s\n", who, strerror(errno));
        return -1;
    }

    /* data came from the network: never assume it is '\0'-terminated */
    printf("[%s] received: seq_no=%u reserved=%u data=\"%.*s\"\n",
           who, m.seq_no, (unsigned)m.reserved, (int)sizeof(m.data), (char *)m.data);
    if (m.reserved != 0)
        fprintf(stderr, "[%s] warning: reserved field is not zero\n", who);

    m.seq_no += 1;
    m.reserved = 0;

    if (send_msg(connfd, &m) < 0) {
        fprintf(stderr, "[%s] error writing to client: %s\n", who, strerror(errno));
        return -1;
    }
    printf("[%s] replied:  seq_no=%u reserved=%u data=\"%.*s\"\n",
           who, m.seq_no, (unsigned)m.reserved, (int)sizeof(m.data), (char *)m.data);
    return 1;
}
