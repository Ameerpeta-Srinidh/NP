#ifndef MESG_H
#define MESG_H

/* The message exchanged between client and server.
 * Defined ONCE here and included by every source file that needs it. */

#define DATA_LEN 16     /* 15 usable characters + terminating '\0' */

struct mesg {
    unsigned int   seq_no;
    unsigned short reserved;            /* must always be 0 */
    unsigned char  data[DATA_LEN];
};

#endif
