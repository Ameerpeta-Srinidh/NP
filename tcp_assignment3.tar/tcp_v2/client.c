#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "common.h"

#define NUM_MESSAGES 5
#ifndef SLEEP_SECS
#define SLEEP_SECS 5            /* override with -DSLEEP_SECS=1 only for quick tests */
#endif

static int connect_to_server(const struct sockaddr_in *addr)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }
    if (connect(fd, (const struct sockaddr *)addr, sizeof(*addr)) < 0) {
        fprintf(stderr, "Error: cannot connect to server: %s\n", strerror(errno));
        close(fd);
        exit(EXIT_FAILURE);
    }
    return fd;
}

static void build_message(struct mesg *m, const char *text)
{
    memset(m, 0, sizeof(*m));           /* also zeroes reserved and any padding */
    m->seq_no = (unsigned int)rand();   /* a fresh random number for EVERY message */
    m->reserved = 0;
    strncpy((char *)m->data, text, DATA_LEN - 1);   /* length already checked in main */
}

static void print_msg(const char *label, const struct mesg *m)
{
    printf("%s seq_no=%u reserved=%u data=\"%.*s\"\n", label, m->seq_no,
           (unsigned)m->reserved, (int)sizeof(m->data), (const char *)m->data);
}

int main(int argc, char *argv[])
{
    struct sockaddr_in server_addr;
    struct mesg sent, reply;
    int sockfd, i, rc;

    if (argc != 4) {
        fprintf(stderr, "Usage: %s <ipaddress> <portno> <message>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    if (strlen(argv[3]) > DATA_LEN - 1) {
        fprintf(stderr, "Error: message too long (%zu characters); at most %d are allowed\n",
                strlen(argv[3]), DATA_LEN - 1);
        exit(EXIT_FAILURE);
    }
    if (fill_sockaddr(&server_addr, argv[1], argv[2]) < 0)
        exit(EXIT_FAILURE);

    /* different seed for every client, even if started in the same second */
    srand((unsigned int)time(NULL) ^ (unsigned int)getpid());

    /* a dead server must give us an error from write(), not kill us */
    signal(SIGPIPE, SIG_IGN);

    sockfd = connect_to_server(&server_addr);

    for (i = 0; i < NUM_MESSAGES; i++) {
        build_message(&sent, argv[3]);

        if (send_msg(sockfd, &sent) < 0) {
            fprintf(stderr, "Error: cannot send to server: %s\n", strerror(errno));
            close(sockfd);
            exit(EXIT_FAILURE);
        }
        print_msg("sent    :", &sent);

        rc = recv_msg(sockfd, &reply);
        if (rc == 0) {
            fprintf(stderr, "Error: server closed the connection before replying\n");
            close(sockfd);
            exit(EXIT_FAILURE);
        }
        if (rc < 0) {
            fprintf(stderr, "Error: cannot read reply from server: %s\n", strerror(errno));
            close(sockfd);
            exit(EXIT_FAILURE);
        }
        print_msg("received:", &reply);

        if (reply.seq_no != sent.seq_no + 1 ||
            memcmp(reply.data, sent.data, DATA_LEN) != 0)
            fprintf(stderr, "Warning: reply does not match what was sent\n");

        sleep(SLEEP_SECS);
    }

    close(sockfd);
    exit(EXIT_SUCCESS);
}
